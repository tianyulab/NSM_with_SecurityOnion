#!/bin/env python
#Override variables here if needed
#This is lazy man's config file - gets loaded as a python script inline
#self.loglevel = logging.DEBUG
#self.logtype = 'stdout'
#self.silkconf = '/data/silk.conf'
#each CGI query can give maximum number of rows.
#self.maxrows = 1000
#10 years of data search allowed
#self.maxdays=3650
